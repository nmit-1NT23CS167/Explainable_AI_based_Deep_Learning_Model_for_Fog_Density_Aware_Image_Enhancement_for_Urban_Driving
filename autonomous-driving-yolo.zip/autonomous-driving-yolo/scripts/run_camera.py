"""
Run detection on a live camera / stream, displayed in a window.
Press 'q' in the window to quit.

Examples:
    python scripts/run_camera.py --model yolo11 --source 0
    python scripts/run_camera.py --model yolo26 --source rtsp://192.168.1.10:554/stream
"""

import argparse
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.detector import UrbanYOLODetector
from src.utils import VALID_MODELS


def main():
    parser = argparse.ArgumentParser(description="Run YOLO detection on a live camera feed.")
    parser.add_argument("--model", required=True, choices=VALID_MODELS,
                         help="Which model to run: yolo11 | yolo12 | yolo26 | yoloe")
    parser.add_argument("--source", default="0",
                         help="Camera index (e.g. 0) or a stream URL (RTSP/HTTP)")
    parser.add_argument("--weights", default=None, help="Optional custom .pt checkpoint")
    parser.add_argument("--conf", type=float, default=None, help="Confidence threshold")
    parser.add_argument("--iou", type=float, default=None, help="NMS IoU threshold")
    parser.add_argument("--imgsz", type=int, default=None, help="Inference image size")
    parser.add_argument("--device", default=None, help="cpu | 0 | auto")
    parser.add_argument("--no-filter", action="store_true",
                         help="Disable filtering to driving-relevant classes")
    args = parser.parse_args()

    # Camera index vs. stream URL
    source = int(args.source) if args.source.isdigit() else args.source

    detector = UrbanYOLODetector(
        model_key=args.model,
        weights=args.weights,
        conf=args.conf,
        iou=args.iou,
        imgsz=args.imgsz,
        device=args.device,
        filter_driving_classes=not args.no_filter,
    )
    detector.run_on_camera(source)


if __name__ == "__main__":
    main()
