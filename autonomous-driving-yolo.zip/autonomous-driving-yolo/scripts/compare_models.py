"""
Run all 4 models (YOLO11, YOLO12, YOLO26, YOLOE) on the same image and
report per-model inference time + detection counts, side by side.

Example:
    python scripts/compare_models.py --source data/images/street.jpg
"""

import argparse
import sys
import time
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.detector import UrbanYOLODetector
from src.utils import VALID_MODELS


def main():
    parser = argparse.ArgumentParser(description="Compare all 4 YOLO models on one image.")
    parser.add_argument("--source", required=True, help="Path to a single image")
    parser.add_argument("--save-dir", default="data/outputs/comparison")
    args = parser.parse_args()

    print(f"{'Model':<10} {'Detections':<12} {'Time (ms)':<12}")
    print("-" * 34)

    for model_key in VALID_MODELS:
        detector = UrbanYOLODetector(model_key=model_key)
        start = time.time()
        results = detector.run_on_image(args.source, save_dir=args.save_dir)
        elapsed_ms = (time.time() - start) * 1000
        n_detections = sum(len(r.boxes) for r in results if r.boxes is not None)
        print(f"{model_key:<10} {n_detections:<12} {elapsed_ms:<12.1f}")

    print(f"\nAnnotated outputs saved under: {args.save_dir}")


if __name__ == "__main__":
    main()
