"""
Pre-download all 4 model checkpoints into ./weights/ so first-run inference
doesn't pause to fetch them. Ultralytics auto-downloads on first load, this
just does it up front for all models at once.

Example:
    python scripts/download_weights.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from ultralytics import YOLO
from src.model_loader import load_config

WEIGHTS_DIR = Path(__file__).resolve().parent.parent / "weights"


def main():
    cfg = load_config()
    WEIGHTS_DIR.mkdir(exist_ok=True)

    for key, model_cfg in cfg["models"].items():
        checkpoint = model_cfg["checkpoint"]
        print(f"Downloading {key} -> {checkpoint} ...")
        YOLO(checkpoint)  # triggers auto-download to the ultralytics cache
        print(f"  done.")

    print("\nAll checkpoints downloaded and cached.")


if __name__ == "__main__":
    main()
