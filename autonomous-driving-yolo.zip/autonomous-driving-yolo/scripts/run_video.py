"""
Run detection on a video file and save an annotated copy.

Examples:
    python scripts/run_video.py --model yolo12 --source data/videos/city_drive.mp4
    python scripts/run_video.py --model yolo26 --source data/videos/city_drive.mp4 --conf 0.3
"""

import argparse
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.detector import UrbanYOLODetector
from src.utils import VALID_MODELS


def main():
    parser = argparse.ArgumentParser(description="Run YOLO detection on a video file.")
    parser.add_argument("--model", required=True, choices=VALID_MODELS,
                         help="Which model to run: yolo11 | yolo12 | yolo26 | yoloe")
    parser.add_argument("--source", required=True, help="Path to a video file")
    parser.add_argument("--weights", default=None, help="Optional custom .pt checkpoint")
    parser.add_argument("--conf", type=float, default=None, help="Confidence threshold")
    parser.add_argument("--iou", type=float, default=None, help="NMS IoU threshold")
    parser.add_argument("--imgsz", type=int, default=None, help="Inference image size")
    parser.add_argument("--device", default=None, help="cpu | 0 | auto")
    parser.add_argument("--save-dir", default="data/outputs", help="Output folder")
    parser.add_argument("--no-filter", action="store_true",
                         help="Disable filtering to driving-relevant classes")
    args = parser.parse_args()

    detector = UrbanYOLODetector(
        model_key=args.model,
        weights=args.weights,
        conf=args.conf,
        iou=args.iou,
        imgsz=args.imgsz,
        device=args.device,
        filter_driving_classes=not args.no_filter,
    )
    detector.run_on_video(args.source, save_dir=args.save_dir)


if __name__ == "__main__":
    main()
