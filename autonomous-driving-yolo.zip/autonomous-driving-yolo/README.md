# Urban Autonomous Driving — Multi-Model YOLO Object Detection

Real-time object detection for urban autonomous-driving perception (pedestrians,
vehicles, cyclists, traffic lights, signs, etc.), built on **four** Ultralytics
YOLO model families so you can compare speed vs. accuracy vs. flexibility:

| Key      | Model  | Notes |
|----------|--------|-------|
| `yolo11` | YOLO11 | Strong general-purpose anchor-free detector |
| `yolo12` | YOLO12 | Attention-centric architecture, higher accuracy |
| `yolo26` | YOLO26 | Newest (2026) NMS-free, end-to-end model — fastest edge inference |
| `yoloe`  | YOLOE  | Open-vocabulary "detect anything" via text prompts (not limited to COCO's 80 classes) |

All four are driven through Ultralytics' single unified Python API, so the
same code path handles **image**, **video**, and **live camera** input for
every model.

---

## 1. Folder structure

```
autonomous-driving-yolo/
├── README.md                  # this file
├── requirements.txt           # pip dependencies
├── .gitignore
│
├── config/
│   └── models.yaml            # checkpoint names + driving-relevant classes + default thresholds
│
├── src/
│   ├── __init__.py
│   ├── model_loader.py        # loads YOLO11 / YOLO12 / YOLO26 / YOLOE via one API
│   ├── detector.py            # UrbanYOLODetector: run_on_image / run_on_video / run_on_camera
│   ├── driving_classes.py     # COCO subset + YOLOE text-prompt classes relevant to driving
│   └── utils.py                # small helpers (input-type detection, etc.)
│
├── scripts/
│   ├── run_image.py           # CLI: detect on a single image or folder
│   ├── run_video.py           # CLI: detect on a video file, saves annotated .mp4
│   ├── run_camera.py          # CLI: detect on a live webcam / RTSP stream
│   ├── compare_models.py      # CLI: run all 4 models on one image, compare speed/counts
│   └── download_weights.py    # pre-download all 4 checkpoints
│
├── webapp/                    # Streamlit website
│   ├── __init__.py
│   ├── app.py                 # main Streamlit app (image + video + SHAP)
│   ├── detection_utils.py     # results->DataFrame, video processing loop
│   └── shap_explain.py        # SHAP explainability (model-agnostic, any of the 4 families)
│
├── data/
│   ├── images/                # put input images here
│   ├── videos/                # put input videos here
│   └── outputs/                # annotated results are written here
│
├── weights/                   # downloaded .pt checkpoints get cached here
└── notebooks/                 # optional space for exploratory analysis
```

---

## 2. Setup

```bash
# 1. Clone / unzip the project, then enter it
cd autonomous-driving-yolo

# 2. Create a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) pre-download all 4 model checkpoints up front
python scripts/download_weights.py
```

> Ultralytics auto-downloads any checkpoint the first time it's used, so
> step 4 is optional — it just avoids a download pause during your first
> `run_image.py` / `run_video.py` / `run_camera.py` call.

**GPU note:** if you have a CUDA GPU, install a CUDA-enabled `torch` build
first (see https://pytorch.org/get-started/locally/) before
`pip install -r requirements.txt`, then pass `--device 0` to any script.

---

## 3. Execution commands

### 3.1 Image input

```bash
# Single image
python scripts/run_image.py --model yolo11 --source data/images/street.jpg

# Folder of images
python scripts/run_image.py --model yolo26 --source data/images/ --conf 0.35

# Open-vocabulary YOLOE
python scripts/run_image.py --model yoloe --source data/images/street.jpg
```
Annotated output is saved to `data/outputs/<model>_images/`.

### 3.2 Video input

```bash
python scripts/run_video.py --model yolo12 --source data/videos/city_drive.mp4
python scripts/run_video.py --model yolo26 --source data/videos/city_drive.mp4 --conf 0.3 --device 0
```
Annotated `.mp4` is saved to `data/outputs/<model>_video/`.

### 3.3 Live camera / stream input

```bash
# Default webcam (index 0)
python scripts/run_camera.py --model yolo11 --source 0

# RTSP / IP camera stream
python scripts/run_camera.py --model yolo26 --source rtsp://192.168.1.10:554/stream
```
Opens a live window with boxes drawn in real time. Press **`q`** to quit.

### 3.4 Compare all 4 models on one image

```bash
python scripts/compare_models.py --source data/images/street.jpg
```
Prints a per-model table of detection count and inference time, and saves
each model's annotated output under `data/outputs/comparison/`.

---

## 4. Common CLI flags (all scripts)

| Flag | Default | Description |
|---|---|---|
| `--model` | *required* | `yolo11` \| `yolo12` \| `yolo26` \| `yoloe` |
| `--source` | *required* | image/folder path, video path, or camera index/URL |
| `--weights` | model default | path to a custom fine-tuned `.pt` checkpoint |
| `--conf` | `0.25` | confidence threshold |
| `--iou` | `0.45` | NMS IoU threshold |
| `--imgsz` | `640` | inference resolution |
| `--device` | `auto` | `cpu` \| `0` (GPU index) \| `auto` |
| `--no-filter` | off | disable filtering to driving-relevant classes, show all detected classes |

Driving-relevant classes (person, bicycle, car, motorcycle, bus, truck,
traffic light, stop sign, etc.) are defined in `src/driving_classes.py` and
`config/models.yaml`, and are applied by default for YOLO11/12/26. YOLOE is
prompted directly with an urban-driving vocabulary (including free-text
concepts like "pothole" and "construction cone") via `model.set_classes()`.

---

## 5. Using your own fine-tuned weights

If you fine-tune any of these models on a driving dataset (e.g. BDD100K,
Cityscapes, KITTI, nuImages):

```bash
python scripts/run_image.py --model yolo11 --weights runs/train/exp1/weights/best.pt --source data/images/
```

To train from scratch/fine-tune, use the standard Ultralytics CLI, e.g.:

```bash
yolo detect train model=yolo11n.pt data=path/to/driving_data.yaml epochs=100 imgsz=640
yolo detect train model=yolo26n.pt data=path/to/driving_data.yaml epochs=100 imgsz=640
```

---

## 6. Streamlit website

A single-page website (`webapp/app.py`) that wraps all 4 model families in
one UI, with image and video input, an annotated-output view, a detections
table, and an optional SHAP explainability panel.

### 6.1 Run it

```bash
pip install -r requirements.txt   # already includes streamlit, pandas, shap, matplotlib
streamlit run webapp/app.py
```

This opens the app at **http://localhost:8501**.

### 6.2 What's in the UI

**Sidebar menu:**
- **Model family** — YOLO11 / YOLO12 / YOLO26 / YOLOE (open-vocabulary)
- **Model size** — n (nano, fastest) / s (small, balanced) / m (medium, most accurate)
- Confidence threshold, IoU threshold, inference size sliders
- "Only show driving-relevant classes" toggle
- **SHAP explainability** — checkbox + max-evaluations slider
- Video settings — frame stride and max frames to process (keeps CPU demos responsive)

**🖼️ Image tab:**
- Upload a `.jpg/.jpeg/.png/.bmp/.webp`
- Shows the annotated output image, summary metrics (detection count,
  unique classes, inference time), and a **detections table** (class,
  confidence, x1/y1/x2/y2) with a CSV download button
- Optional **SHAP explanation**: a heatmap per detected class showing which
  image regions increased (red) or decreased (blue) that class's confidence

**🎬 Video tab:**
- Upload a `.mp4/.avi/.mov/.mkv/.m4v`, click "Run detection on video"
- Shows the annotated video, summary metrics, a full detections table
  (with a `frame` column) + CSV download, and a per-class bar chart
- SHAP is intentionally **not** run per video frame (too slow for
  interactive use) — extract a frame and explain it in the Image tab instead

### 6.3 How the model menu maps to checkpoints

| Family | size=n | size=s | size=m |
|---|---|---|---|
| YOLO11 | `yolo11n.pt` | `yolo11s.pt` | `yolo11m.pt` |
| YOLO12 | `yolo12n.pt` | `yolo12s.pt` | `yolo12m.pt` |
| YOLO26 | `yolo26n.pt` | `yolo26s.pt` | `yolo26m.pt` |
| YOLOE  | `yoloe-11n-seg.pt` | `yoloe-11s-seg.pt` | `yoloe-11m-seg.pt` |

Checkpoints auto-download from Ultralytics on first use of each combination
and are cached locally, so switching models in the dropdown may pause
briefly the first time.

### 6.4 How SHAP explainability works here

SHAP is built for classifiers, so `webapp/shap_explain.py` wraps the YOLO
model in a small function that returns, per class, the highest confidence
score YOLO assigns anywhere in the (possibly perturbed) image. SHAP's
**Partition explainer** then blurs out super-pixel regions of the input,
re-runs the model, and measures how each region's presence/absence moves
that confidence score — producing a heatmap of which regions the model
actually relied on. This is model-agnostic (no architecture-specific code),
so it works identically across YOLO11/12/26 and YOLOE, but it is a **post-hoc,
perturbation-based** explanation, not a true gradient/internal-activation
explanation, and it re-runs the model up to `max_evals` times per image —
raise that slider for a smoother heatmap, lower it for speed.

### 6.5 Screenshot layout reference

The app follows a simple two-column layout: annotated output on the left,
summary metrics on the right, with the detections table and (optional) SHAP
panel underneath — similar in spirit to a typical "upload → detect →
inspect" dashboard, but generalized here to plain object detection across
all 4 model families rather than a single fixed use case.

---

## 7. Troubleshooting

- **No camera window opens / OpenCV error**: make sure you're running
  locally (not headless/SSH without a display), and that no other app is
  using the webcam.
- **Slow inference on CPU**: use the `n` (nano) checkpoint variants (already
  the defaults), lower `--imgsz` (e.g. `480`), or run on GPU with `--device 0`.
- **YOLOE detects nothing**: check/extend the prompt list in
  `src/driving_classes.py -> YOLOE_PROMPT_CLASSES`.
