"""
Helpers used by webapp/app.py:
  - results_to_dataframe(): turn an Ultralytics Results object into a tidy
    pandas DataFrame for the on-screen detections table.
  - process_video(): run a model over an uploaded video, write an annotated
    copy to disk, and collect a detections dataframe across frames.
"""

import cv2
import numpy as np
import pandas as pd


def results_to_dataframe(result, frame_idx: int | None = None) -> pd.DataFrame:
    """
    result: a single Ultralytics `Results` object (one image/frame).
    frame_idx: optional frame number, added as a column for video results.
    """
    rows = []
    if result.boxes is not None and len(result.boxes) > 0:
        xyxy = result.boxes.xyxy.cpu().numpy()
        confs = result.boxes.conf.cpu().numpy()
        cls_ids = result.boxes.cls.cpu().numpy().astype(int)
        for (x1, y1, x2, y2), conf, cid in zip(xyxy, confs, cls_ids):
            row = {
                "class": result.names.get(int(cid), str(cid)),
                "confidence": round(float(conf), 3),
                "x1": round(float(x1), 1),
                "y1": round(float(y1), 1),
                "x2": round(float(x2), 1),
                "y2": round(float(y2), 1),
            }
            if frame_idx is not None:
                row = {"frame": frame_idx, **row}
            rows.append(row)

    cols = (["frame"] if frame_idx is not None else []) + [
        "class", "confidence", "x1", "y1", "x2", "y2"
    ]
    return pd.DataFrame(rows, columns=cols)


def process_video(model, input_path: str, output_path: str, conf: float, iou: float,
                   imgsz: int, class_filter: list[int] | None, frame_stride: int = 1,
                   max_frames: int = 300, progress_callback=None):
    """
    Runs detection over an uploaded video, writes an annotated .mp4 to
    `output_path`, and returns a combined detections DataFrame across the
    processed frames.

    frame_stride : only run inference every Nth frame (skipped frames are
                   still written to the output video un-annotated, to keep
                   playback speed/duration correct).
    max_frames   : hard cap on frames actually *processed* through the
                   model, to keep the demo responsive on CPU.
    """
    cap = cv2.VideoCapture(input_path)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {input_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    all_rows = []
    frame_idx = 0
    processed = 0

    while True:
        ok, frame_bgr = cap.read()
        if not ok:
            break

        run_inference = (frame_idx % frame_stride == 0) and (processed < max_frames)

        if run_inference:
            result = model.predict(
                source=frame_bgr, conf=conf, iou=iou, imgsz=imgsz,
                classes=class_filter, verbose=False,
            )[0]
            annotated = result.plot()  # BGR frame with boxes drawn
            df = results_to_dataframe(result, frame_idx=frame_idx)
            if not df.empty:
                all_rows.append(df)
            processed += 1
        else:
            annotated = frame_bgr

        writer.write(annotated)
        frame_idx += 1

        if progress_callback and total_frames > 0:
            progress_callback(min(frame_idx / total_frames, 1.0))

    cap.release()
    writer.release()

    detections_df = (
        pd.concat(all_rows, ignore_index=True) if all_rows
        else pd.DataFrame(columns=["frame", "class", "confidence", "x1", "y1", "x2", "y2"])
    )
    return detections_df, frame_idx, processed
