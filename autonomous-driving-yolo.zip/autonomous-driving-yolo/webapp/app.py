"""
Urban Object Detection — Streamlit website

A single web app to run object detection with YOLO11 / YOLO12 / YOLO26 /
YOLOE (each with n / s / m size options) on an uploaded image or video,
view the annotated output, a table of detections, and an optional SHAP
explanation of which image regions drove the detections.

Run with:
    streamlit run webapp/app.py
"""

import sys
import time
import tempfile
from pathlib import Path

import cv2
import numpy as np
import streamlit as st

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.model_loader import load_model_dynamic, VALID_SIZES, load_config
from src.driving_classes import DRIVING_COCO_CLASSES
from webapp.detection_utils import results_to_dataframe, process_video
from webapp.shap_explain import explain_image

# --------------------------------------------------------------------------
# Page setup
# --------------------------------------------------------------------------
st.set_page_config(page_title="Urban Object Detection", layout="wide", page_icon="🚦")

MODEL_LABELS = {
    "yolo11": "YOLO11",
    "yolo12": "YOLO12",
    "yolo26": "YOLO26",
    "yoloe": "YOLOE (open-vocabulary)",
}

st.title("🚦 Urban Object Detection")
st.caption(
    "Detect people, vehicles, traffic infrastructure, and more, using "
    "YOLO11 / YOLO12 / YOLO26 / YOLOE — with optional SHAP explainability."
)

# --------------------------------------------------------------------------
# Sidebar — model menu + settings
# --------------------------------------------------------------------------
with st.sidebar:
    st.header("Settings")

    model_key = st.selectbox(
        "Model family",
        options=list(MODEL_LABELS.keys()),
        format_func=lambda k: MODEL_LABELS[k],
        help="YOLO11/12/26 are fixed to COCO's 80 classes. YOLOE is "
             "open-vocabulary and is prompted with a driving-relevant "
             "class list defined in src/driving_classes.py.",
    )

    model_size = st.selectbox(
        "Model size",
        options=VALID_SIZES,
        index=0,
        format_func=lambda s: {"n": "n — nano (fastest)",
                                "s": "s — small (balanced)",
                                "m": "m — medium (most accurate)"}[s],
    )

    conf_threshold = st.slider("Confidence threshold", 0.05, 0.95, 0.25, 0.05)
    iou_threshold = st.slider("IoU (NMS) threshold", 0.05, 0.95, 0.45, 0.05)
    imgsz = st.select_slider("Inference size", options=[320, 480, 640, 960], value=640)

    filter_driving = st.checkbox("Only show driving-relevant classes", value=True)

    st.divider()
    st.subheader("SHAP explainability")
    run_shap = st.checkbox("Run SHAP explanation (image mode only)", value=False)
    shap_max_evals = st.slider(
        "SHAP max evaluations", 20, 300, 100, 10,
        help="Higher = smoother, more reliable heatmap, but slower. "
             "Each evaluation is a full model forward pass.",
        disabled=not run_shap,
    )

    st.divider()
    st.subheader("Video settings")
    frame_stride = st.slider("Process every Nth frame", 1, 10, 2)
    max_frames = st.slider("Max frames to process", 10, 600, 150, 10)


@st.cache_resource(show_spinner="Loading model...")
def get_model(model_key: str, model_size: str):
    return load_model_dynamic(model_key, model_size)


model, task, checkpoint = get_model(model_key, model_size)
class_names = model.names if isinstance(model.names, dict) else {i: n for i, n in enumerate(model.names)}

class_filter = None
if filter_driving and model_key != "yoloe":
    wanted = set(DRIVING_COCO_CLASSES)
    class_filter = [i for i, n in class_names.items() if n in wanted]

st.sidebar.success(f"Loaded checkpoint: `{checkpoint}`")

# --------------------------------------------------------------------------
# Main tabs — Image / Video
# --------------------------------------------------------------------------
tab_image, tab_video = st.tabs(["🖼️ Image", "🎬 Video"])

# ============================== IMAGE TAB ================================
with tab_image:
    uploaded_image = st.file_uploader(
        "Upload an image", type=["jpg", "jpeg", "png", "bmp", "webp"], key="img_upload"
    )

    if uploaded_image is not None:
        file_bytes = np.frombuffer(uploaded_image.read(), np.uint8)
        image_bgr = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

        with st.spinner("Running detection..."):
            start = time.time()
            result = model.predict(
                source=image_bgr, conf=conf_threshold, iou=iou_threshold,
                imgsz=imgsz, classes=class_filter, verbose=False,
            )[0]
            elapsed_ms = (time.time() - start) * 1000

        annotated_bgr = result.plot()
        annotated_rgb = cv2.cvtColor(annotated_bgr, cv2.COLOR_BGR2RGB)
        df = results_to_dataframe(result)

        col_img, col_metrics = st.columns([2, 1])
        with col_img:
            st.subheader("Annotated output")
            st.image(annotated_rgb, use_container_width=True)
        with col_metrics:
            st.subheader("Summary")
            st.metric("Total detections", len(df))
            st.metric("Unique classes", df["class"].nunique() if not df.empty else 0)
            st.metric("Inference time", f"{elapsed_ms:.0f} ms")
            st.metric("Model", f"{MODEL_LABELS[model_key]} ({model_size})")

        st.subheader("Detections table")
        if df.empty:
            st.info("No objects detected above the current confidence threshold.")
        else:
            st.dataframe(df, use_container_width=True)
            st.download_button(
                "Download detections as CSV",
                df.to_csv(index=False).encode("utf-8"),
                file_name="detections.csv",
                mime="text/csv",
            )

        # ---------------------------- SHAP -------------------------------
        if run_shap:
            st.subheader("SHAP explanation")
            if df.empty:
                st.info("Nothing was detected, so there is nothing to explain.")
            else:
                target_classes = df["class"].unique().tolist()[:4]  # cap for speed
                with st.spinner(
                    f"Computing SHAP values for {target_classes} "
                    f"({shap_max_evals} evaluations, this can take a while on CPU)..."
                ):
                    try:
                        fig = explain_image(
                            model, image_rgb, target_classes,
                            max_evals=shap_max_evals, imgsz=imgsz, conf=conf_threshold,
                        )
                        st.pyplot(fig)
                        st.caption(
                            "Red regions pushed the model's confidence for that class "
                            "up; blue regions pushed it down. Computed by perturbing "
                            "(blurring) super-pixel regions and observing the effect "
                            "on per-class confidence (SHAP PartitionExplainer)."
                        )
                    except Exception as e:
                        st.error(f"SHAP explanation failed: {e}")
    else:
        st.info("Upload an image to run detection.")

# ============================== VIDEO TAB =================================
with tab_video:
    uploaded_video = st.file_uploader(
        "Upload a video", type=["mp4", "avi", "mov", "mkv", "m4v"], key="vid_upload"
    )

    if uploaded_video is not None:
        tmp_in = tempfile.NamedTemporaryFile(delete=False, suffix=Path(uploaded_video.name).suffix)
        tmp_in.write(uploaded_video.read())
        tmp_in.close()

        tmp_out_path = str(Path(tempfile.gettempdir()) / f"annotated_{Path(uploaded_video.name).stem}.mp4")

        run_button = st.button("Run detection on video")

        if run_button:
            progress_bar = st.progress(0.0, text="Processing video...")

            def _progress(pct):
                progress_bar.progress(pct, text=f"Processing video... {pct*100:.0f}%")

            with st.spinner("Running detection on video (this may take a while)..."):
                start = time.time()
                df, total_frames, processed_frames = process_video(
                    model, tmp_in.name, tmp_out_path,
                    conf=conf_threshold, iou=iou_threshold, imgsz=imgsz,
                    class_filter=class_filter, frame_stride=frame_stride,
                    max_frames=max_frames, progress_callback=_progress,
                )
                elapsed_s = time.time() - start

            progress_bar.empty()

            col_vid, col_metrics = st.columns([2, 1])
            with col_vid:
                st.subheader("Annotated output")
                st.video(tmp_out_path)
            with col_metrics:
                st.subheader("Summary")
                st.metric("Total detections", len(df))
                st.metric("Frames processed", f"{processed_frames}/{total_frames}")
                st.metric("Unique classes", df["class"].nunique() if not df.empty else 0)
                st.metric("Total time", f"{elapsed_s:.1f} s")
                st.metric("Model", f"{MODEL_LABELS[model_key]} ({model_size})")

            st.subheader("Detections table")
            if df.empty:
                st.info("No objects detected above the current confidence threshold.")
            else:
                st.dataframe(df, use_container_width=True)
                st.download_button(
                    "Download detections as CSV",
                    df.to_csv(index=False).encode("utf-8"),
                    file_name="video_detections.csv",
                    mime="text/csv",
                )

                st.markdown("**Detections per class**")
                st.bar_chart(df["class"].value_counts())

            st.caption(
                "SHAP explanation is only available in Image mode (running it "
                "per video frame would be far too slow for interactive use). "
                "Extract a frame as an image to explain it."
            )
    else:
        st.info("Upload a video and click 'Run detection on video'.")
