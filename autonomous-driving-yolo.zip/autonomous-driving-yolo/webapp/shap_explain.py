"""
SHAP explainability for object detection.

SHAP was built for classifiers, not detectors, so we adapt it: we wrap the
YOLO model in a small "prediction function" that takes a batch of images and
returns, for each image, a confidence score per driving-relevant class (the
max confidence across all detected boxes of that class, 0 if absent). SHAP's
Partition explainer then perturbs (blurs out) super-pixel regions of the
input image and measures how each region's presence/absence pushes those
per-class confidence scores up or down — giving a heatmap of which pixels
the model relied on for its detections.

This is a post-hoc, model-agnostic explanation (not a gradient-based
saliency map), so it works identically for every model family (YOLO11/12/26
and even open-vocab YOLOE) with no architecture-specific code.

Note: this is computationally heavier than a normal forward pass. Keep
`max_evals` modest (default 100) for interactive use.
"""

import cv2
import numpy as np
import shap
import matplotlib.pyplot as plt


def _make_predict_fn(model, class_names, imgsz=640, conf=0.15):
    """
    Returns f(images: np.ndarray[N,H,W,3] uint8) -> np.ndarray[N, num_classes]
    where each column is the max confidence YOLO assigned to that class
    in that (possibly perturbed/blurred) image.
    """
    name_to_idx = {name: i for i, name in enumerate(class_names)}

    def predict_fn(images: np.ndarray) -> np.ndarray:
        images = images.astype(np.uint8)
        scores = np.zeros((images.shape[0], len(class_names)), dtype=np.float32)

        # SHAP's masker perturbs in RGB; Ultralytics treats raw numpy array
        # sources as BGR (same convention as cv2.imread), so convert back.
        bgr_batch = [cv2.cvtColor(img, cv2.COLOR_RGB2BGR) for img in images]

        results = model.predict(
            source=bgr_batch, imgsz=imgsz, conf=conf, verbose=False
        )
        for i, r in enumerate(results):
            if r.boxes is None or len(r.boxes) == 0:
                continue
            cls_ids = r.boxes.cls.cpu().numpy().astype(int)
            confs = r.boxes.conf.cpu().numpy()
            for cid, c in zip(cls_ids, confs):
                cname = r.names.get(int(cid), str(cid))
                if cname in name_to_idx:
                    idx = name_to_idx[cname]
                    scores[i, idx] = max(scores[i, idx], float(c))
        return scores

    return predict_fn


def explain_image(model, image_rgb: np.ndarray, target_classes: list[str],
                   max_evals: int = 100, imgsz: int = 640, conf: float = 0.15):
    """
    Run a SHAP Partition explanation for the given classes on a single image.

    image_rgb      : HxWx3 uint8 RGB numpy array
    target_classes : list of class names to explain (usually the ones
                      actually detected in the image, so the explanation is
                      relevant to what's shown)
    max_evals       : SHAP perturbation budget - higher = smoother/slower

    Returns: matplotlib Figure ready to hand to st.pyplot()
    """
    if len(target_classes) == 0:
        raise ValueError("No target classes to explain (nothing was detected).")

    predict_fn = _make_predict_fn(model, target_classes, imgsz=imgsz, conf=conf)

    masker = shap.maskers.Image("blur(32,32)", image_rgb.shape)
    explainer = shap.Explainer(predict_fn, masker, output_names=target_classes)

    shap_values = explainer(
        np.expand_dims(image_rgb, axis=0),
        max_evals=max_evals,
        batch_size=8,
        outputs=shap.Explanation.argsort.flip[: len(target_classes)],
    )

    fig = plt.figure()
    shap.image_plot(shap_values, show=False)
    fig = plt.gcf()
    return fig
