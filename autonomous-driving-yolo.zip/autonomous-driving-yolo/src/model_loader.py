"""
Loads any of the 4 supported model families through Ultralytics' unified
`YOLO` API, applying the extra setup that YOLOE needs (open-vocabulary
class prompting via set_classes()).
"""

import yaml
from pathlib import Path
from ultralytics import YOLO

from src.driving_classes import YOLOE_PROMPT_CLASSES

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "models.yaml"


def load_config():
    with open(CONFIG_PATH, "r") as f:
        return yaml.safe_load(f)


# Valid size suffixes we expose in the UI. YOLO checkpoints also come in
# l/x variants, but n/s/m cover the fast <-> accurate range requested here.
VALID_SIZES = ["n", "s", "m"]


def build_checkpoint_name(model_key: str, size: str) -> str:
    """
    Build the Ultralytics checkpoint filename for a given model family + size.

    Standard families:  yolo11n.pt, yolo11s.pt, yolo11m.pt, yolo12n.pt, ...
    YOLOE (open-vocab):  yoloe-11n-seg.pt, yoloe-11s-seg.pt, yoloe-11m-seg.pt
                         (YOLOE ships on top of the YOLO11 backbone family)
    """
    if size not in VALID_SIZES:
        raise ValueError(f"size must be one of {VALID_SIZES}, got '{size}'")

    if model_key == "yoloe":
        return f"yoloe-11{size}-seg.pt"
    if model_key in ("yolo11", "yolo12", "yolo26"):
        return f"{model_key}{size}.pt"
    raise ValueError(f"Unknown model_key '{model_key}'")


def load_model_dynamic(model_key: str, size: str, weights_override: str | None = None):
    """
    Load a model by family + size (used by the Streamlit UI, which exposes
    an n/s/m dropdown for every model family).

    Returns: (model, task, checkpoint_name)
    """
    cfg = load_config()
    if model_key not in cfg["models"]:
        raise ValueError(
            f"Unknown model '{model_key}'. Choose one of: {list(cfg['models'].keys())}"
        )
    family = cfg["models"][model_key]["family"]
    task = cfg["models"][model_key]["task"]
    checkpoint = weights_override or build_checkpoint_name(model_key, size)

    model = YOLO(checkpoint)
    if family == "open_vocab":
        model.set_classes(YOLOE_PROMPT_CLASSES)

    return model, task, checkpoint


def load_model(model_key: str, weights_override: str | None = None):
    """
    model_key: one of "yolo11", "yolo12", "yolo26", "yoloe"
    weights_override: optional path/name to a custom .pt checkpoint
                       (e.g. your own fine-tuned weights)

    Returns: (model, task, model_cfg)
    """
    cfg = load_config()
    if model_key not in cfg["models"]:
        raise ValueError(
            f"Unknown model '{model_key}'. Choose one of: {list(cfg['models'].keys())}"
        )

    model_cfg = cfg["models"][model_key]
    checkpoint = weights_override or model_cfg["checkpoint"]

    model = YOLO(checkpoint)

    # YOLOE is open-vocabulary: it needs class prompts set before inference.
    if model_cfg["family"] == "open_vocab":
        model.set_classes(YOLOE_PROMPT_CLASSES)

    return model, model_cfg["task"], model_cfg
