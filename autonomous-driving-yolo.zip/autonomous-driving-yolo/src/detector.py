"""
Unified detector wrapper around Ultralytics YOLO models.

Supports 3 input modes for any of the 4 model families (YOLO11, YOLO12,
YOLO26, YOLOE):
    - image  : single image file or a folder of images
    - video  : a video file, saved back out with boxes drawn
    - camera : a live webcam / RTSP / USB camera stream, shown in a window

Ultralytics' `model.predict(..., stream=True)` already natively handles all
of these source types (path, folder, video file, or an integer camera
index / stream URL), so this class is mostly a thin, well-documented layer
on top of it plus driving-relevant class filtering and output bookkeeping.
"""

from pathlib import Path
import cv2

from src.model_loader import load_model, load_config
from src.driving_classes import DRIVING_COCO_CLASSES


class UrbanYOLODetector:
    def __init__(self, model_key: str, weights: str | None = None, conf: float | None = None,
                 iou: float | None = None, imgsz: int | None = None, device: str | None = None,
                 filter_driving_classes: bool = True):
        self.cfg = load_config()
        infer_cfg = self.cfg["inference"]

        self.model, self.task, self.model_cfg = load_model(model_key, weights)
        self.model_key = model_key

        self.conf = conf or infer_cfg["confidence"]
        self.iou = iou or infer_cfg["iou"]
        self.imgsz = imgsz or infer_cfg["image_size"]
        self.device = None if (device in (None, "auto")) else device

        # Only makes sense for the fixed-vocabulary COCO models. YOLOE
        # already only "sees" the classes we prompted it with.
        self.class_filter = None
        if filter_driving_classes and self.model_cfg["family"] == "standard":
            names_by_id = self.model.names  # {id: name}
            wanted = set(DRIVING_COCO_CLASSES)
            self.class_filter = [i for i, n in names_by_id.items() if n in wanted]

    # ------------------------------------------------------------------ #
    # IMAGE
    # ------------------------------------------------------------------ #
    def run_on_image(self, source: str, save_dir: str = "data/outputs"):
        """source: path to a single image OR a folder of images."""
        results = self.model.predict(
            source=source,
            conf=self.conf,
            iou=self.iou,
            imgsz=self.imgsz,
            device=self.device,
            classes=self.class_filter,
            save=True,
            project=save_dir,
            name=f"{self.model_key}_images",
            exist_ok=True,
        )
        print(f"[{self.model_key}] Saved annotated image(s) to "
              f"{Path(save_dir) / (self.model_key + '_images')}")
        return results

    # ------------------------------------------------------------------ #
    # VIDEO FILE
    # ------------------------------------------------------------------ #
    def run_on_video(self, source: str, save_dir: str = "data/outputs"):
        """source: path to a video file. Writes an annotated .mp4 to save_dir."""
        results = self.model.predict(
            source=source,
            conf=self.conf,
            iou=self.iou,
            imgsz=self.imgsz,
            device=self.device,
            classes=self.class_filter,
            save=True,
            stream=True,          # process frame-by-frame, memory friendly
            project=save_dir,
            name=f"{self.model_key}_video",
            exist_ok=True,
        )
        for _ in results:
            pass  # consume the generator to actually run + write the video
        print(f"[{self.model_key}] Saved annotated video to "
              f"{Path(save_dir) / (self.model_key + '_video')}")

    # ------------------------------------------------------------------ #
    # LIVE CAMERA / STREAM
    # ------------------------------------------------------------------ #
    def run_on_camera(self, source: int | str = 0, window_name: str | None = None):
        """
        source: integer webcam index (0 = default camera), or an RTSP/HTTP
                 stream URL.
        Opens a live display window; press 'q' to quit.
        """
        window_name = window_name or f"Urban Driving Detection - {self.model_key}"
        stream = self.model.predict(
            source=source,
            conf=self.conf,
            iou=self.iou,
            imgsz=self.imgsz,
            device=self.device,
            classes=self.class_filter,
            stream=True,   # yields results frame-by-frame for a live feed
        )

        for result in stream:
            annotated_frame = result.plot()  # numpy BGR frame with boxes drawn
            cv2.imshow(window_name, annotated_frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        cv2.destroyAllWindows()
