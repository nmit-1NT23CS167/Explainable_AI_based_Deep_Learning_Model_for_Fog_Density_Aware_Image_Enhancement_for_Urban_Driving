"""
Class lists relevant to urban autonomous-driving perception.

- DRIVING_COCO_CLASSES: subset of the 80 COCO classes that standard
  detectors (YOLO11 / YOLO12 / YOLO26, all COCO-pretrained) can already
  recognise and that matter for driving scenes.

- YOLOE_PROMPT_CLASSES: a slightly richer open-vocabulary list that we feed
  into YOLOE's `set_classes()` at runtime, since YOLOE is not limited to the
  fixed 80-class COCO taxonomy.
"""

DRIVING_COCO_CLASSES = [
    "person",
    "bicycle",
    "car",
    "motorcycle",
    "bus",
    "truck",
    "traffic light",
    "fire hydrant",
    "stop sign",
    "parking meter",
    "train",
]

# Open-vocabulary prompts for YOLOE - free text, not limited to COCO.
YOLOE_PROMPT_CLASSES = [
    "person",
    "pedestrian",
    "car",
    "bus",
    "truck",
    "motorcycle",
    "bicycle",
    "traffic light",
    "traffic sign",
    "stop sign",
    "road barrier",
    "pothole",
    "lane marking",
    "construction cone",
]
