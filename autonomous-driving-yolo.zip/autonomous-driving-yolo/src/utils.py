"""Small shared helpers used by the scripts/ entry points."""

from pathlib import Path

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".m4v"}


def guess_source_type(source: str) -> str:
    """
    Best-effort guess of whether `source` is an image, video, or camera
    index, so scripts can sanity-check user input.
    """
    if source.isdigit():
        return "camera"
    path = Path(source)
    if path.suffix.lower() in IMAGE_EXTS:
        return "image"
    if path.suffix.lower() in VIDEO_EXTS:
        return "video"
    if path.is_dir():
        return "image"  # folder of images
    return "unknown"


VALID_MODELS = ["yolo11", "yolo12", "yolo26", "yoloe"]
